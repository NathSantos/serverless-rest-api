# serverless-rest-api
Serverless REST API - AWS Practice
